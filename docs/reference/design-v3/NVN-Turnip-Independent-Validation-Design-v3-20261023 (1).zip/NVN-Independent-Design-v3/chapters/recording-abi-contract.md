# 修订3：可开工的录制、ABI 与消费时点合同

## 0. 范围与证据等级

这是拟新增实现规格，不把私有格式冒充 Nintendo 命令格式。证据索引及反例见 audit-api-recording.md。首个可构建目标是 host CPU library + fake backend；首个 device backend 只消费同一 IR。正式 NVN 函数入口和64位参数转发与内部格式分离。

建立两条明确 profile：

1. `typed-v1`：只从拦截的API生成命令，64位command handle为不复用token；本文可立即实现、无需GPU。未知inline读写或native编码不能准入。不是“全部 NVN 已兼容”。
2. `raw-compat:<game-build>:<sdk-profile>`：guest观察的对象字节、command字节、内存用量与patch模板逐项有证据。可沿用已验证的紧凑host记录模板，但不能宣称理解所有Maxwell包。native backend IR仅是派生缓存。

D2R初版以typed profile起步，静态使用优先加入；是否可用typed profile运行D2R须通过直接命令内存访问审计及运行写集资格，不因静态没有GetMemoryUsed调用就假定不存在inline访问。未知入口resolver拒绝并记录一次，不返回成功nop。

## 1. 文件/模块边界

- frontend/abi_profile.{h,c}：目标ABI、对象允许写范围、inline字段、外部句柄编码、已资格枚举及错误返回策略。
- frontend/object_registry.{h,c}：对象身份和生命周期，不知道GPU寄存器。
- frontend/command_storage.{h,c}：命令/控制双arena、回调桥、预算和range tracker。
- frontend/recording.{h,c}：API→内部记录，全部值参数验证及原子追加。
- frontend/bytecode.{h,c}：typed验证/解码、raw profile adapter，禁止裸cast不可信字节为C struct。
- frontend/command_cache.{h,c}：版本化IR块和反向依赖失效。
- frontend/sync_state.{h,c}：FenceEpoch、EventRef、QueryEpoch和有序执行IR。
- frontend/descriptor_view.{h,c}：执行消费视图，稀疏slot版本选择。

模块内部状态返回 NvnnResult（详细拒绝原因另列）；void NVN入口不能凭空返回错误值。适配层将失败转入该device的诊断/拒绝状态，阻止含半记录的handle提交；正式queue error输出ABI未知时不能写猜测大小的结构。

## 2. ABI profile 与对象 registry

AbiProfile 必填：profile_id、game_build、ptr_width=64、endianness=little、calling_convention、bool_width=1、enum_width=4、每对象minimum_known_extent及allowed_write_ranges、inline_field_rules、handle_policy、callback trampoline、supported entry signatures。

候选头的reserved[]大小只做来源信息，不能当真实guest分配大小。未确认范围默认零写入。API Initialize一般可以仅注册外部地址，不在guest内写host指针；需要SDK内联行为的profile由专门codec维护guest字节。禁止整个对象memset。禁止把+0x10未知字段拿来存end指针。guest栈对象也用registry，不依赖guest内host标记。

ObjectKey=(device_id,guest_address,kind)；ObjectRef=(registry_id,generation)。Record包括 Lifecycle、AbiProfileId、规范化host元数据、引用计数、retirement_set、可选guest inline mirror版本。Lifecycle为 UNINITIALIZED→LIVE→FINALIZING→RETIRED。Initialize同址新代数；kind不符、double init、失效引用受诊断。Finalize从lookup删除LIVE资格，原有已允许引用保留host记录至引用归零且全部queue points完成。

并非所有对象均延迟同样内容：Bind固定状态复制规范化值，故state对象可不持久引用；BindProgram固定 ProgramVersion；PoolRef/TextureRef等引用寿命按命令/descriptor所需保留。Finalize不是许可继续读取guest原对象的理由。shader control/data若异步编译，必须按已确定ProgramSetShaders消费合同保存所需字节/稳定storage引用，不只浅复制NVNshaderData指针。

ABI桥测试：小端uint64、负ptrdiff、count<0、NVNboolean低8位、单字段8字节struct句柄的调用约定、callback参数顺序、输出参数canary。不把host native typedef跨平台当guest ABI。

## 3. Recorder 状态机与双arena

Recorder字段：ObjectRef、state、owner_thread、callback_fn/data、callback_depth、command_arena、control_arena、recording_id、pending_record、error、budget_profile。状态 IDLE→RECORDING→IDLE；任意失败→POISONED；Finalize→DEAD。IDLE允许换arena/config；RECORDING允许Append/补arena/End；重复Begin、无Begin的End、DEAD调用拒绝。POISONED不能产出有效handle。

Arena字段：arena_id、generation、kind、guest_extent、cursor、usable_end、budget_origin、used_since_add、segment_list、storage_use_set。command存储关联PoolRef+logicalRange；control存储关联注册的CPU range。不得把GPUVA当CPUptr。所有offset/size/cursor加法先做overflow和containment检查，负offset直接拒绝。

typed-v1格式预算与native包预算完全独立。typed-v1 ControlRecord固定32字节，8字节对齐：u32 kind、u32 byte_size=32、u64 logical_owner、u64 target、u64 aux。kind=1是HandleManifest，End时收费一次；kind=2是跨segment link，换段时收费一次；kind=3是Call edge，每个被调handle一次。host IR缓存、native描述符缓存不向guest control预算重复收费。此收费是私有profile约定，不是NVN实测。

AddCommandMemory/AddControlMemory注册新的当前segment；不隐式释放以前segment。顶层Add从此重设对应budget_origin和used_since_add，已封存handle保留自己的segment manifest。RECORDING内因callback补充允许链接旧segment。raw profile需要重现其观察到的累计计数策略，不能直接沿用typed定义。任何在途仍使用的重叠存储覆盖，先检测非法复用，不通过代数掩盖。

Begin不分配synthetic BEGIN记录。End写8字节END，创建32字节control manifest并sealed handle；空录制也有合法END。Free返回物理可用剩余，appendable_free另扣链接保留，不混淆；Size/Used/Free的对外定义由profile固定。

Append事务：先规范化与复制临时值参数→计算两类需求→ensure_capacity→保留两arena区间→写payload→最后发布header和cursor。任何失败不发布半条记录；若callback已成功添加arena但记录失败，允许arena结构变化，不能声称全部API无副作用。Copy大块可多条原子提交但必须保持目标recording整体可回滚或poison，禁止输出半Copy的可执行handle。

## 4. 回调与线程规则

ensure_capacity以kind选择event0/1，size为该profile要求的最小补充量（含alignment和必要link reserve）；不能固定只发event0。保存当前fn/data快照，置callback_depth，释放registry/arena/queue锁，使用guest ABI trampoline同步调用。回调返回后重新lookup recorder代数和state，检测被Finalize/换对象，重新计算容量，不能继续使用旧host指针。

回调在同线程允许：AddCommandMemory、AddControlMemory、Get*Memory*、Get/SetMemoryCallbackData及profile允许的配置；禁止对同recorder Begin/End/Append/Finalize的递归GPU录制。其他recorder可独立录制。没有补足需求的回调返回视为无进展，返回OOM并poison，不固定重试两次掩盖错误、不无限重试。用户更换callback供后续exhaustion使用，不递归重试新callback。

每recorder单写者；不同recorder可并行。Registry可短锁；调用guest callback、backend wait、编译器时不得持有全局锁。Queue API用每queue线性化锁，实际等待在锁外。EventGetValue和CPU Signal采用资源同步合同，不能凭C volatile宣称线程安全。异步错误只锁存诊断，不能从driver工作线程重入guest callback。

## 5. typed-v1字节码与验证

所有多字节小端；记录8字节对齐。header为u16 opcode、u16 flags、u32 byte_length（含header，>=8且8倍数）。不得将其直接定义为外部NVN布局。opcode版本受profile id控制，未知opcode/flags拒绝；END长度8。payload中的引用为内部u64 registry token，绝不存C指针。每handle manifest记录profile_id、segment ids/epochs、范围、record_count、direct_ref_set、nested_call_edges、content_version和digest。

第一批opcode：END、CALL、BIND_STATE、BIND_PROGRAM、SET_DESCRIPTOR_POOL、BIND_DESCRIPTOR_SELECTOR、BIND_BUFFER、DRAW、DISPATCH、BARRIER、COPY_BUFFER、UPDATE_BUFFER、WAIT_SYNC、FENCE_SYNC、WAIT_EVENT、SIGNAL_EVENT、RESET_QUERY、REPORT_QUERY。枚举数值在单一generated internal header维护，不能沿用旧OP枚举ordinal碰巧相同。

具体payload：

- CALL：u64 command_token；byte_length=16。数组API在返回前复制n个token，n=0不读数组；不保留数组指针。
- BIND_DESCRIPTOR_SELECTOR：u32 stage、u32 slot、u64 selector；length=24。pool身份取命令执行state，不在这里冻结全部pool。
- SET_DESCRIPTOR_POOL：u32 kind、u32 reserved、u64 PoolRefToken；length=24。
- UPDATE_BUFFER：u64 address、u64 buffer_size、i64 offset、u32 data_size、u32 reserved、data[data_size]及零padding。data在录制前完整读取复制；length=align8(40+data_size)，所有求和范围检查。真实NVN的size/alignment限制由entry profile验证。
- WAIT_SYNC：u64 SyncRefToken；length=16；入队实例解析为FenceEpochRef，不改原始封存记录。
- WAIT_EVENT：u64 EventRefToken、u32 mode、u32 value；length=24。
- SIGNAL_EVENT：u64 EventRefToken、u32 mode、u32 location、u32 flags、u32 value；length=32。不能丢loc/flags。
- RESET_QUERY：u32 type、u32 reserved；length=16。
- REPORT_QUERY：u32 type、u32 report_profile、u64 dstLogicalAddress；length=24。

bytecode验证先验证整个direct stream及范围，再解析对象refs和DAG；无递归C调用栈，迭代walker+显式frame stack。检测循环、超出manifest的JUMP、截断payload、整数溢出、重叠非法记录。深度/总展开量有profile上限和诊断，不写任意“16层就是NVN限制”。typed跨segment链接存在control manifest，不在客体字节里存裸指针。

## 6. Call、Copy、句柄与patch cache

typed-v1的Call捕获被调handle身份；执行按该handle当次准入的内容版本，不保存调用时整个资源内容。Copy复制来源直接记录及inline payload；对来源中CALL仅复制其引用边，不递归冻结被调块。内部可共享不可变块以省拷贝，但Copy目标的直接记录版本不能随源patch改变。Copy时确认来源完整sealed，锁定内容epoch，在复制完成前若被改写则重试一致快照或失败，不输出混合版本。

raw NVN Copy语义尚未资格。D2R临时准入可证明来源及传递调用集合在目标最后消费前不可变、存活且未重用，此时reference/copy观察等价；没有证明则拒绝该资格，不能默默沿用OP_CALL。源代码现有hacks不算证明。

typed句柄token全进程单调唯一（溢出停止）；FinalizeCommandHandle解除未来提交资格，已提交instance仍保留版本。raw句柄可能就是地址，地址本身不能区分ABA；profile规定重新录制旧存储前旧handle必须退出合法使用区间。同一个外部数值对应当前可见storage epoch，不允许猜测用户意图。

patch cache key=(profile,handle_id,content_version,backend_arch,resource_binding_abi)。dirty tracking依赖guest命令实际range，host写记录时更新同一版本。修改selector只invalidate对应block与依赖摘要，非全frame。raw LM3模板保持single-bind handle在+0x10；其他未知patch拒绝，不把其误读为count。提交时生成稳定解码版本及native batch，完成前保留旧版本；未来submit见新版本。guest与正在执行command字节的无序并发修改不在此机制中自动变合法，按原API race/同步合同验证。

## 7. 消费时点与描述符规则

四个时点：HOST(API当场)、RECORD(固化值)、ENQUEUE(队列线性化/版本选择)、GPU_ORDERED(实际执行读取)。不得把四者合并成“提交读取所有数据”。

- setters/getters、callback配置：HOST。
- fixed-state Bind、view参数数组、draw标量、handle数组、UpdateUniformBuffer源数据：RECORD。
- program内容：按ProgramVersion消费合同固化所需编译输入；不浅拷贝指针后任意晚读。
- vertex/index/indirect/SSBO/image字节、event值：GPU_ORDERED。
- descriptor选择器：RECORD；其引用slot在已资格有序消费点解析；typed-v1 ENQUEUE选择提交视图，后续CPU更新必须排序到下一消费epoch。对于允许执行期间更新的正式NVN用法，此profile不够，需独立live-table协议，不伪装支持。

SubmissionDescriptorView包含(pool identity,generation,slot→DescriptorVersion)的稀疏映射、实际可达slots集合、GPU native root和retirement_set。没有全池poolSnapshot，也没有每draw复制整个pool。register预编码候选描述符；只有存在在途冲突时复制受影响native页/槽。没有冲突原地更新+必要cache invalidate。旧提交保持旧native页，后续提交选择新版本。shader动态索引证明不了可达集合时保护该绑定池允许范围，并记录成本，不只保护绑定的单个slot。

缓存命中仍登记本次访问依赖、map epoch、publication依赖和ticket。若槽内容未改但纹理内容变了，描述符编码可以复用，资源可见性依然重新纳入图。

## 8. Sync/Event/Query执行实例

SyncObject={ObjectRef,state:UNFENCED|BOUND|FINALIZING,currentFenceEpoch}。FenceEpoch={unique_id,queue_id,ordered_position,condition,flags,completion_points,publication_scope}。重新Fence创建新epoch，不覆盖旧等待者的ticket。typed-v1 WaitSync在ENQUEUE锁存当前epoch；未Fence返回未满足依赖，不伪造success。CPU SyncWait锁存进入调用时epoch，timeout单位ns、0不阻塞，区分already signaled/condition satisfied/timeout/device failure。正式NVN何时锁存另列oracle门禁。

QueueFenceSync排序在pending queue当前位置；不是全局x_fence()。CommandBufferFenceSync在执行位置产生epoch实例，重放每次一个新实例。实际硬件支持不同scope时才映射条件；用submit尾完成替代早期condition仅在不产生额外依赖cycle并允许保守延迟的资格路径启用，并统计损失。

EventRef={PoolRef,logical_offset,32-bit width,alignment profile}。Initialize不修改value。CPU/GPU访问走统一alias和cache域；GetValue不得返回host缓存旧值。WRITE=0、ADD=1；按明确atomic协议实现ADD，不能CPU load/store与GPU RMW并发。EQUAL直接32位相等；typed-v1 GEQUAL_WRAP私有定义为 `(uint32_t)(actual-target)<0x80000000`，恰好半环差为false；该定义未获原机语义验证，不作为NVN已支持证据。location对应执行scope，TOP不等价完成callback；VERTEX_PIPE需后端明确stage支持；unknown flags拒绝。

QueryEpoch=(queue,logical_counter_type,reset_sequence)；Reset和Report是有序命令。Report capture当前累计值后写logical目标，不在录制时写回。typed-v1仅定义TIMESTAMP=0、SAMPLES_PASSED=1、TIMESTAMP_TOP=16，报告为两个little-endian u64: value,timestampTicks；tick单位来自profile，有证据的候选为19.2MHz但正式NVN资格须核对。内部GPU原始tick→guest tick使用宽乘除避免ns*12溢出。timestamp应在对应GPU位置采样，不能使用CPU completion clock。TOP和BOTTOM分别放置事件。

跨tile samples使用每tile同一逻辑epoch的部分和，binning阶段不双记；多个Report之间不隐式Reset；internal meta draw/query不能污染guest计数。输出alias视作GPU写依赖，CPU可见点需完成+cache维护。其余14种/特殊结构按真实枚举实现或拒绝，不返回伪0；报告不添加未经证明的availability word。

## 9. 阶段验收与门禁

V01：registry+ABI桥，ASan/UBSan canary测试覆盖0x80 texture/16byte view、commandBuffer+0x10写入不影响host指针、地址同值新代数。首版只host运行自编测试，不运行仓库游戏代码。

V02：双arena与事务Append。32/64/512byte小segment压力；独立control不足；回调补容量/无进展/更换userdata；callback内另一个recorder正常；同recorder递归Append被拒绝；End恰好使用末8bytes；连续Begin/End统计不清零错误。

V03：Call/Copy/patch。A含CallB、CopyA到C、改A不改C、改B依profile影响A/C；循环拒绝；同址句柄ABA；提交1后patch提交2，两批native视图互不污染；修改1块不重编其他块。

V04：descriptor/sync/query fake executor。录制bind后register新slot、submit可见新slot；未改变descriptor但资源publication变化仍发依赖；sync二次Fence不改旧等待epoch；event wrap边界和ADD冲突；多tile samples与线性reference一致；timestamp位置严格有序而非提交尾同值。

D2R准入清单：逐实际调用点枚举与flags、command存储直接写集、Copy可观察性/生命周期、sync锁存点、report输出ABI、SDK对象profile。清单尚未齐备就只标“CPU核心可开工/可测试”，不得标“原生D2R backend可开跑”。这避免以524行条目数替代真正语义闭合。
