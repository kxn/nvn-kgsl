# Turnip/KGSL 开工前静态审计：bootstrap、构建闭包与补丁来源

## 结论

上一版的 BackendOps 是目标接口，不是已有 Mesa 可调用库。第一阶段必须采用 **Mesa 内部同一 DSO 的 native bridge**，保留现有冷启动 Vulkan runtime/device 初始化，先绕过逐 draw 的 Vulkan 资源/描述符/命令 API，再逐步拆内部 emitter。不要第一周就删除 Vulkan runtime、另造 tu_device、复制 KGSL ioctl 和 compiler 初始化。保留冷路径 Vk 类型不等于继续用 Vulkan 翻译热路径。

第一条可实施路线为：普通 BO → 离屏 CP 写入/读回 → 固定 descriptor/root ABI → shader编译与链接 → sysmem draw及有界replay。Android WSI与host import按真实负载分别准入；GMEM后置。统一顺序以implementation-backlog的V01–12为准，B0–B6是技术主题而非强制顺序。host import、native ASTC、VBO均不是普通BO离屏闭环的前置。新增源码和构建本次未实施；此处是精确实施清单，不是编译/GPU通过报告。

## 1. 固定证据版本

- Mesa：8e557130bda2adcb87535aabe23bca0d68ff77b6，https://gitlab.freedesktop.org/mesa/mesa/-/tree/8e557130bda2adcb87535aabe23bca0d68ff77b6 。以下 Mesa 路径均相对此树。
- 主应用：kxn/d2r-mobile 5803e32592ba2cdfc6d3460bb61267453c2ee5fe。
- **新找回** host import：kxn/d2r-mobile，codex/turnip-host-import-ext-v2，f122a40c2bc70017d163653ef91676133e9a7303。
- **新找回** host image：同库 codex/turnip-host-image-native-v1，5c8da4df76784230adf30bd25f39063478084962。
- wait 错误分类：同库 codex/turnip-kgsl-wait-error-classification，be9c3dbff24b1a2a6a967c5a4ab0415adce986a9。

上述三个独立分支已实际 git ls-remote 验证，并按完整 SHA fetch、读取源码；不是从分支名猜测。补丁本地原样保存在 evidence/host-import-ext-v2.patch 和 evidence/host-image-native-v1.patch。

## 2. P0 修正：host-import 不是源码缺失，但 f830 还不是可重建的完整 provenance

完整公开路径：

- https://github.com/kxn/d2r-mobile/tree/f122a40c2bc70017d163653ef91676133e9a7303/scripts/dev/experimental-turnip-host-import
- https://github.com/kxn/d2r-mobile/tree/5c8da4df76784230adf30bd25f39063478084962/scripts/dev/experimental-turnip-host-image
- https://github.com/kxn/d2r-mobile/tree/be9c3dbff24b1a2a6a967c5a4ab0415adce986a9/scripts/dev/turnip

这不是需要从 libadrenotools 猜出来的新功能。host-import v2 的完整 patch 已提供：

1. tu_knl.h：bo.imported_host_ptr、bo_init_host_ptr vtable 与内部入口。
2. tu_knl_kgsl.cc：kgsl_import_host_pages、kgsl_probe_host_import、kgsl_bo_init_host_ptr、BO销毁借用 VMA 特例。
3. tu_knl.cc：host pointer 页对齐、非零、CPU端溢出检查；Map 原地址、禁止异址 placed map；reserve-unmap 拒绝；普通 Unmap 不改变应用映射。
4. tu_device.cc / tu_buffer.cc：Vulkan EXT capability、memory types、buffer bind范围、heap accounting与失败回滚。
5. 启动只在 TU_DM_HOST_IMPORT=true 且普通 cached coherent 支持、真实一页 ADDR import/INFO/release probe成功时启用。

KGSL validator 的细节可以直接复用，不能只摘 ioctl：ADDR 的 priv_len 是**导入字节长度**而非 sizeof(useraddr)；IMPORT返回 flags 和 INFO flags 都必须保留 WRITEBACK|IOCOHERENT；INFO size必须等于申请extent；gpuaddr非零且加size不溢出；拒绝 USE_CPU_MAP / GPUREADONLY / SECURE。成功并不要求 CPU VA=GPU VA。错误路径释放已创建 kernel ID。调用者持有原 VMA 身份直到所有GPU用途完成并释放导入。

host-image 分支是一个完整combined patch，不是应在 host-import patch 后再叠加的增量。README称基于 frozen 3c871 host-buffer source；builder实际以**完整combined patch**应用 Mesa26.2.5 archive。不可把两个 patch顺序 apply造成重复定义。它只开放 optimal 2D ASTC4x4/6x6 UNORM/sRGB、单layer/depth/sample、1..16mips、flags0、exclusive、初始UNDEFINED、SAMPLED+HOST_TRANSFER、可选TRANSFER；禁UBWC/LRZ、storage/attachment/sparse/mutable及override chains。原生 backend可复用 layout/eligibility和导入机制，不应继承这些 Vulkan用途限制作通用NVN限制；首版资格仍保持该窄profile。

两个builder均固定 Mesa26.2.5 archive SHA256 794b3d1729075dae7ebd47c7283b7ca0cdb5dec668f7f11cc0a5d82f6138a0a5，并验证archive+patch完整树、symlink、缓存产物和manifest。主分支 scripts/dev/build-turnip.py 则明确是 unmodified archive builder，不能用于产生这些patched代码。

f830的已找证据更精确但不完整：wait分支 qualification.json 将 driver SHA f830285fe68f0a744792269da5f160ed8636c172b1f6511db9d99478e1a2acce 对应原 tu_knl_kgsl.cc SHA 691fcd1f5b90643da3165c3329fd939a86d662646a7802845a1578c1a5ed48c7，并记录 NDK28.2.13676358/API34 单TU及1091依赖校验。其状态明确 NOT_LINKED_NOT_DEPLOYED。公开记录没有提供完整原f830树/完整产物manifest，因此不能证明5c8补丁单独重建等于f830，更不能把wait补丁当已部署修复。结论应改为“核心定制补丁已定位可复用；f830二进制完整可重建链仍待归档”，不阻断新身份 native DSO 构建。

## 3. P0：真实链接闭包不允许四文件 mini-driver

src/freedreno/vulkan/meson.build 实际 shared_library('vulkan_freedreno')输入包括：libtu_files、tu_drirc、tu_entrypoints、tu_tracepoints、freedreno XML headers、sha1_h、u_format_pack_h、bvh_spv及float32/64 SPIR-V生成文件。链接 libfreedreno_ir3、libfreedreno_layout、libfreedreno_perfcntrs，依赖 idep_nir、idep_vulkan_util/runtime/wsi、idep_libfreedreno_common、idep_mesautil、线程/dl/elf/m 等。

KGSL由 freedreno-kmds.contains('kgsl')添加 TU_HAS_KGSL和tu_knl_kgsl.cc。不能拿独立CMake编译tu_cs/tu_knl/tu_shader后宣布形成backend：生成头、CHIP模板实例、vk对象分配、util sparse数组、sync类型、trace符号都会缺。第一阶段沿用这个完整target，native bridge追加到libtu_files，不删源文件；以编译器/linker暴露的真实依赖为依据后续拆分。

GNU hidden visibility和Vulkan linker version-script还会把新增入口隐藏。Android使用 src/vulkan/vulkan-android.sym及vulkan-icd-android-symbols.txt；不要污染所有ICD的公共列表。给native-enabled Turnip目标专用export map/symbol allowlist，同时保留既有Android ICD符号，显式导出唯一tu_nvn_get_interface_v1。关闭native选项时原符号表完全不变。以readelf动态符号及dlopen/dlsym测试验收，不能只看头文件可编译。

## 4. P0：设备构造不是打开 /dev/kgsl-3d0

证据：tu_device.cc:2819 tu_CreateDevice；tu_queue.cc:615 tu_queue_init；tu_knl_kgsl.cc:1814 kgsl_device_init。

kgsl_device_init只是借用physical_device->local_fd，不拥有独立fd；tu_knl_kgsl_load负责physical-device探索、heap/ION探测及设备属性。真正设备构造还初始化vk_device dispatch/features、bo/submit/pipeline/trace等锁、bo_map、queues、vk_meta、ir3 compiler、pipeline/event/visibility suballocators、global BO、clear/blit/empty shaders、dynamic rendering、pipeline cache、sub_cs、perf/autotune和trace。错误标签是完整逆序释放链。

首版bridge用**同一实例/物理设备/设备/队列**的既有构造和析构；不手动memset tu_device并填fd。可以支持own-device或borrow-existing-device二选一，但首版只实现own-device，避免两个所有者同时销毁。对应用仅暴露opaque句柄，不泄露tu_device布局。CreateDevice后所有native提交与任何WSI提交共享同一queue互斥；不允许vk runtime线程和native线程无序同时操作queue->fence。

## 5. P0：提交包装会复制命令地址，不替你保活 BO

tu_knl_kgsl.cc:1390起 kgsl_submit_add_entries 将 tu_cs_entry 变成kgsl_command_object，复制gpuaddr,size,id，不增加源BO ref。tu_submit_finish只清host dynarrays，不表示GPU退休。native SubmissionRecord必须自己持有IB、root、descriptor、shader、data、image和外部buffer引用直到completion。不要以“ioctl已返回”释放tu_cs的BO。

初版非空IB走tu_submit_create/add_entries/tu_queue_submit，复用vk_sync同步类型；no-op/wait-only必须继续复用KGSL已有merge predecessor逻辑。kgsl_queue_submit会在成功后更新queue->fence并signal timestamp；出错可能device lost，不能把失败当作未执行然后覆盖原内存。EPROTO可能发生在已进入GPU工作的情况下，需进入lost/quarantine，不能把“CPU函数返回失败”当可复用证明。

KGSL timestamp是context内32位序号。native64 serial与实际timestamp、context-generation绑定；不能将uint32负载扩为全局完成时间。多queue retirement用依赖集合。首次实现单真实queue，不开启emulated second queue，避免同步重定向混入raw提交。

## 6. BO/VMA/fd明确所有权

|来源|fd|CPU VMA|GPU地址|销毁|
|---|---|---|---|---|
|ordinary GPUMEM_ALLOC_ID|借用physical local_fd|bo_map新建，由BO拥有|kernel返回，生命周期稳定|退休后unmap一次，FREE_ID一次|
|DMA heap/ION新allocation|allocator返回fd由helper拥有；tu_bo_init_dmabuf另dup|driver mmap其dup|INFO返回|helper import后close原fd，无论成功失败；BO关闭dup|
|外部dma-buf import|调用者fd借用，driver own dup|driver所建VMA owned|INFO返回|不close调用者fd；退休后关闭own dup和kernelID|
|ADDR host import|不另建长期fd；借用设备fd|应用拥有RW alias，driver borrowed|INFO返回，和CPU VA独立|只FREE_ID，不munmap/free应用VMA|
|acquire/release sync_file|与dma-buf不同的fd协议|无|无|见WSI契约；每个transfer只关闭一次|

额外修复点：当前Mesa kgsl_bo_init_dmabuf直接将os_dupfd_cloexec(fd)赋给shared_fd，未检查失败；若EMFILE后仍返回成功，后续bo_map会误走KGSLfd路径。native adapter应在创建任何可见对象前检查dup失败，释放新import ID，不能把-1解释成ordinary BO。tu_device_lookup_bo后的OOM也不能依赖assert保证安全。以上是新bridge应处理的失败注入，不声称当前已修复。

placed map普通路径使用MAP_FIXED，禁止native应用向任意现存guest地址调用它。首版placed_addr=NULL；将应用guest指针与BO映射显式区分。hostptr patch里的never_unmap本身不足够，因为kgsl_bo_finish原版绕过tu_bo_unmap而直接munmap，必须保留imported_host_ptr销毁特例。

地址范围：校验offset<=logical_size、length<=logical_size-offset；分配rounding后的mmapsize不是允许guest访问padding的许可。CPU ptr+size、GPUVA+offset+length逐级溢出检查；alignment使用实际OS页及硬件descriptor要求。TU_BO_ALLOC_NO_32B_ROLLOVER会强制低4GiB，不能给全部大guest池使用；仅对真实要求该标志的IB/pipeline域沿用tu_bo_ib_flags。禁止假设任意hostptr可落入32-bit IOVA或SVM。

缓存：ordinary allocation cached+coherent请求转WRITEBACK|IOCOHERENT；uncached转WRITECOMBINE。tu_bo_sync_cache实际用util_flush_range/util_flush_inval_range，不是因为KGSL头声明了cache ioctl就改成该ioctl。coherent省CPU cache维护不省execution ordering、GPU UCHE/CCU/texture invalidation。import profile的 flags probe也不证明GPU双向数据路径已测。

## 7. WSI缺口：Android不是tu_wsi.cc这一个文件

Meson在Android下不因KMS而启tu_wsi；ANDROID_native_buffer/AHB能力取决于vk_android_get_ugralloc。Android acquire/release通用实现位于src/vulkan/runtime/vk_android.c，而非tu_queue.cc。

vk_common_AcquireImageANDROID:471明确获得nativeFenceFd所有权，即使失败也要关闭；底层ImportSemaphoreFd失败则不接管原fd，由外层关闭。vk_common_QueueSignalReleaseImageANDROID:568无wait时立即返回-1，**这不表示先前raw KGSL绘制完成**。因此native raw submit必须产出可供同一vk_queue桥接的sync payload/实际完成signal；不能调用零wait release绕过同步。

第一阶段保持offscreen。首次上屏选择同device Vulkan WSI桥：冷创建swapchain/image对象，借用对应tu_image layout/BO，native绘制实际wait acquire并signal可导出sync，沿既有present路径；每帧可以保留一笔WSI提交，不影响去除逐draw descriptor成本。另一种ANativeWindow直连是独立后续实验，必须处理dequeue/cancel/queue ownership、gralloc modifier/stride/UBWC、buffer age、surface lost与producer fence，不许当免费替换。
